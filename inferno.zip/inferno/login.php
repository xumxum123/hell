<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
    background-color: #f8f9fa;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
}
        </style>
    <link rel="stylesheet" href="css/style.css"> 
</head>
<body>
    <div class="auth-container">
        <h1>Login</h1>
        <?php if (isset($erro)) echo "<p class='error'>$erro</p>"; ?>
        <form method="POST" action="">
            <label for="email">E-mail</label>
            <input type="email" id="email" name="email" placeholder="Digite seu e-mail" required>

            <label for="senha">Senha</label>
            <input type="password" id="senha" name="senha" placeholder="Digite sua senha" required>

            <button type="submit">Entrar</button>
        </form>

        <p class="signup-link">
            Ainda não tem uma conta? <a href="cadastro.php">Cadastre-se aqui</a>.
        </p>
    </div>
    <?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $admin_email = "l@admin.com";
    $admin_password = "admin123";
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    if ($email === $admin_email && $senha === $admin_password) {
        header("Location: admin/login.php");
        exit;
    }
    $servername = "localhost";
    $username = "root"; 
    $password = "usbw";
    $dbname = "loja_roupas"; 

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Erro de conexão com o banco de dados: " . $conn->connect_error);
    }
    $sql = "SELECT * FROM usuarios WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $usuario = $result->fetch_assoc();
        if (password_verify($senha, $usuario['senha'])) { 
            header("Location: index.php");
            exit;
        } else {
            $erro = "Senha incorreta!";
        }
    } else {
        $erro = "Usuário não encontrado!";
    }

    $stmt->close();
    $conn->close();
}
?>
</body>
</html>
